-- Adminer 3.7.1 MySQL dump

SET NAMES utf8;
SET foreign_key_checks = 0;
SET time_zone = '+01:00';
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `cms_article`;
CREATE TABLE `cms_article` (
  `id_article` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `prefix` text COLLATE utf8_unicode_ci,
  `text` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_article`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `cms_article` (`id_article`, `title`, `prefix`, `text`, `created_at`) VALUES
(1,	'pokus',	'pokus',	'pokus',	'2015-02-19 13:33:43');

DROP TABLE IF EXISTS `cms_menu`;
CREATE TABLE `cms_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_node` int(11) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `position` int(5) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_node` (`id_node`),
  CONSTRAINT `cms_menu_ibfk_1` FOREIGN KEY (`id_node`) REFERENCES `cms_node` (`id_node`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `cms_menu` (`id`, `id_node`, `title`, `position`) VALUES
(1,	1,	'Pokus',	1),
(2,	12,	'Pokusek',	2);

DROP TABLE IF EXISTS `cms_modules`;
CREATE TABLE `cms_modules` (
  `id_module` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `module_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `module_description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `presenter` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `control` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `model` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `have_admin` tinyint(1) NOT NULL DEFAULT '1',
  `icon` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id_module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `cms_modules` (`id_module`, `uid`, `module_name`, `module_description`, `presenter`, `control`, `model`, `have_admin`, `icon`, `active`) VALUES
(1,	'Article',	'Textový článek',	'',	'Article',	'ArticleControl',	'ArticleModel',	1,	'newspaper-o',	1),
(2,	'Page',	'Stránky',	'',	'Page',	'PageControl',	'PageModel',	1,	'file-o',	1);

DROP TABLE IF EXISTS `cms_node`;
CREATE TABLE `cms_node` (
  `id_node` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_module` int(11) unsigned NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id_node`),
  UNIQUE KEY `slug` (`slug`),
  KEY `id_module` (`id_module`),
  CONSTRAINT `cms_node_ibfk_1` FOREIGN KEY (`id_module`) REFERENCES `cms_modules` (`id_module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `cms_node` (`id_node`, `id_module`, `active`, `slug`, `seo_description`) VALUES
(1,	1,	1,	'pokus',	'pokusny node'),
(6,	2,	1,	'',	''),
(12,	2,	1,	'12-pokus',	NULL),
(13,	2,	1,	'ruzovoucky-beloucky-kun',	NULL);

DROP TABLE IF EXISTS `cms_page`;
CREATE TABLE `cms_page` (
  `id_node` int(11) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci,
  KEY `id_node` (`id_node`),
  CONSTRAINT `cms_page_ibfk_1` FOREIGN KEY (`id_node`) REFERENCES `cms_node` (`id_node`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `cms_page` (`id_node`, `title`, `body`) VALUES
(6,	'pokus',	'pokus'),
(12,	'pokusek',	'pokus'),
(13,	'růžovoučký běloučký kůň',	'Lorem ipsum');

DROP TABLE IF EXISTS `cms_user`;
CREATE TABLE `cms_user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `role` enum('admin','guest') COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `cms_user` (`id_user`, `login`, `name`, `password`, `email`, `role`) VALUES
(1,	'Admin',	'Jiří Jelínek',	'$2y$10$fq6m5igf120u2Y6xwMW7xuiJdU8XhkPalX9Ge3p85Xx0Mw5SuhoAW',	'jelinekvb@gmail.com',	'admin');

-- 2015-02-26 12:55:39
