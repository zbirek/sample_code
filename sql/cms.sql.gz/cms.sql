-- Adminer 4.0.3 MySQL dump

SET NAMES utf8;
SET foreign_key_checks = 0;
SET time_zone = '+01:00';
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `cms_article`;
CREATE TABLE `cms_article` (
  `id_article` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `prefix` text COLLATE utf8_unicode_ci,
  `text` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_article`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `cms_article` (`id_article`, `title`, `prefix`, `text`, `created_at`) VALUES
(1,	'pokus',	'pokus',	'pokus',	'2015-02-19 13:33:43');

DROP TABLE IF EXISTS `cms_modules`;
CREATE TABLE `cms_modules` (
  `id_module` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `module_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `module_description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `presenter` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `control` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `model` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `have_admin` tinyint(1) NOT NULL DEFAULT '1',
  `icon` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id_module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `cms_modules` (`id_module`, `uid`, `module_name`, `module_description`, `presenter`, `control`, `model`, `have_admin`, `icon`, `active`) VALUES
(1,	'Article',	'Textový článek',	'',	'Article',	'ArticleControl',	'ArticleModel',	1,	NULL,	1);

DROP TABLE IF EXISTS `cms_node`;
CREATE TABLE `cms_node` (
  `id_node` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_module` int(11) unsigned NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `seo_description` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id_node`),
  KEY `id_module` (`id_module`),
  CONSTRAINT `cms_node_ibfk_1` FOREIGN KEY (`id_module`) REFERENCES `cms_modules` (`id_module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `cms_node` (`id_node`, `id_module`, `active`, `slug`, `seo_description`) VALUES
(1,	1,	1,	'pokus',	'pokusny node');

-- 2015-02-19 16:01:46
